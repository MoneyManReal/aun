self.__uv$config = {
    prefix: '/86x/science/',
    bare:'https://bare.benrogo.net',
    encodeUrl: Ultraviolet.codec.xor.encode,
    decodeUrl: Ultraviolet.codec.xor.decode,
    handler: '/86x/uv.handler.js',
    bundle: '/86x/uv.bundle.js',
    config: '/86x/uv.config.js',
    sw: '/86x/uv.sw.js',
};
